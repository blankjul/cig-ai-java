package emergence_NI;

import java.util.Comparator;

public class PathComparator implements Comparator<Evolutionary<Path>>{

	
	public static int TYPE = 1;
	
	public static int RANDOM = 0;
	public static int PORTAL = 1;
	public static int NPC = 2;

	@Override
	public int compare(Evolutionary<Path> o1, Evolutionary<Path> o2) {
		Path p1 = (Path) o1;
		Path p2 = (Path) o2;
		
		Double d1 = p1.getScore();
		Double d2 = p2.getScore();
		int result = d2.compareTo(d1);
		if (result == 0) {
			if (TYPE == PORTAL) {
				d1 = p1.portalValue;
				d2 = p2.portalValue;
			} else if (TYPE == NPC) {
				d1 = p1.npcValue;
				d2 = p2.npcValue;
			} else {
				d1 = Agent.r.nextDouble();
				d2 = Agent.r.nextDouble();
			}
			result = d2.compareTo(d1);
		}
		return result;
	}

}
