package emergence_RL;

import core.player.AbstractPlayer;



abstract public class AThreadablePlayer extends AbstractPlayer {

	
	abstract public void initFromString(String parameter);
	
	abstract public String setToString();
	

}
