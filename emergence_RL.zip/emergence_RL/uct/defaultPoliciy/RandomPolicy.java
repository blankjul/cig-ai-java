package emergence_RL.uct.defaultPoliciy;

import ontology.Types;
import core.game.StateObservation;
import emergence_RL.tree.Node;
import emergence_RL.uct.UCTSettings;

public class RandomPolicy extends ADefaultPolicy {


	protected static double[] lastBounds = new double[] { 0, 1 };
	protected static double[] curBounds = new double[] { 0, 1 };

	
	@Override
	public double expand(UCTSettings s, Node n) {

		lastBounds[0] = curBounds[0];
		lastBounds[1] = curBounds[1];

		StateObservation stateObs = n.stateObs.copy();
		int level = n.level;
		while (!n.stateObs.isGameOver() && level <= s.maxDepth) {
			Types.ACTIONS a = n.getRandomAction(s.r);
			stateObs.advance(a);
			++level;
		}

		double normDelta =  getNormalizedReward(stateObs);
		return normDelta;
	}
	
	protected double getNormalizedReward(StateObservation stateObs) {
		double delta = stateObs.getGameScore();

		if (stateObs.isGameOver()) {

			if (stateObs.getGameWinner() == Types.WINNER.PLAYER_WINS)
				return Double.POSITIVE_INFINITY;
			else if (stateObs.getGameWinner() == Types.WINNER.PLAYER_LOSES)
				return Double.NEGATIVE_INFINITY;
		}
		
		if (delta < curBounds[0])
			curBounds[0] = delta;
		if (delta > curBounds[1])
			curBounds[1] = delta;

		double normDelta = normalise(delta, lastBounds[0], lastBounds[1]);
		return normDelta;
	}



}
