package emergence.strategy.astar;

public class AStarInfo {
	
	// costs until now
	public double g = Double.POSITIVE_INFINITY;

	// heuristic value
	public double h = Double.POSITIVE_INFINITY;
	

}
